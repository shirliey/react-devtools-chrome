# Testing React Integration

- `npm install` in the `v0.xx` directories
- `npm install` here
- `webpack-dev-server --hot`

Open `http://localhost:8080`, click a version and you should be running!

Any changes to the test files will make the browser page reload with the new
code, re-running the tests.

## Todo

- [ ] make a page w/ iframes to all of the versions
